﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
using System.IO;
using System.Text;

namespace pr14_1_5_SergeevaAgata
{
    public partial class Form1 : Form
    {
        Stack<int> stack1 = new Stack<int>();
        Stack<int> stack2 = new Stack<int>();
        Queue<int> queue1 = new Queue<int>();
        Queue <Humans> queue2 = new Queue<Humans>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if (int.TryParse((textBox1.Text), out int a))
            {
                int num1 = Convert.ToInt32(textBox1.Text);
                if (num1 > 1)
                {
                    for (int i = 1; i <= num1; i++)
                        stack1.Push(i);
                    while (stack1.Count > 0)
                    {
                        int num2 = (int)stack1.Pop();
                        listBox1.Items.Add(num2);
                    }
                }
                else MessageBox.Show("Введённое число должно быть больше 1!","Ошибка",MessageBoxButtons.OK);
            }
            else MessageBox.Show("Вы ввели не число!", "Ошибка", MessageBoxButtons.OK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamWriter p = File.CreateText("t.txt");
            int count_1 = 0, count_2 = 0;
            if (textBox2.Text != "")
            {
                
                p.WriteLine(textBox2.Text);
                p.Close();
                if (File.Exists("t.txt"))
                {
                    if (File.Exists("t1.txt"))
                    {
                        StreamReader skob = new StreamReader("t.txt");
                        string prim = skob.ReadLine();
                        foreach (char z in prim)
                        {
                            if (z == ')')  count_1++;
                            else if (z == '(') count_2++;
                        }
                        if (count_1 == count_2) listBox2.Items.Add($"В выражениии {textBox2.Text} скобки сбалансированы");
                        else if (count_1 > count_2)
                        {
                            listBox2.Items.Add($"В выражениии {textBox2.Text} скобки не сбалансированы.");
                            listBox2.Items.Add($"Лишняя скобка ) на позиции  {prim.LastIndexOf(")")}");
                            StreamWriter new_ur = new StreamWriter("t1.txt");
                            new_ur.WriteLine("(" + textBox2.Text);
                            new_ur.Close();
                        }
                        else
                        {
                            listBox2.Items.Add($"В выражениии {textBox2.Text} скобки не сбалансированы.");
                            listBox2.Items.Add($"Лишняя скобка ( на позиции  {prim.IndexOf("(")}");
                            StreamWriter new_ur = new StreamWriter("t1.txt");
                            new_ur.WriteLine(textBox2.Text + ")");
                            new_ur.Close();
                        }
                    }
                    else MessageBox.Show("Файл 't.txt'не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("Файл 't.txt'не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Вы не ввели математическое выражение", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            if (int.TryParse((textBox3.Text), out int a))
            {
                int num1 = Convert.ToInt32(textBox3.Text);
                if (num1 > 1)
                {
                    for (int i = 1; i <= num1; i++)
                        queue1.Enqueue(i);
                    while (queue1.Count > 0)
                    {
                        int num2 = (int)queue1.Dequeue();
                        listBox3.Items.Add(num2);
                    }
                }
                else MessageBox.Show("Введённое число должно быть больше 1!", "Ошибка", MessageBoxButtons.OK);
            }
            else MessageBox.Show("Вы ввели не число!", "Ошибка", MessageBoxButtons.OK);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!File.Exists("humans.txt"))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                
                string[] persona = File.ReadAllLines("humans.txt");
                foreach (string pers in persona)
                {
                    string[] chelovek = pers.Split(' ');
                    Humans human = new Humans
                    {
                        lastname = chelovek[0],
                        name = chelovek[1],
                        otfather = chelovek[2],
                        age = Convert.ToInt32(chelovek[3]),
                        weidth = Convert.ToDouble(chelovek[4])
                    };
                    queue2.Enqueue(human);
                }
                var young =queue2.Where(p => p.age < 40);
                foreach (var a in young)
                {
                    listBox4.Items.Add($"{a.lastname} {a.name} {a.otfather} {a.age} {a.weidth}");
                }
                var old = queue2.Where(p => p.age >= 40);
                foreach (var a in old)
                {
                    listBox5.Items.Add($"{a.lastname} {a.name} {a.otfather} {a.age} {a.weidth}");
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (File.Exists("name.txt"))
            {
                if (File.Exists("name.txt"))
                {
                    Queue<string> name = new Queue<string>(File.ReadAllLines("name.txt"));
                    Queue<string> age = new Queue<string>(File.ReadAllLines("age.txt"));
                    
                }
                else MessageBox.Show("Файл 'age.txt' не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Файл 'name.txt' не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
