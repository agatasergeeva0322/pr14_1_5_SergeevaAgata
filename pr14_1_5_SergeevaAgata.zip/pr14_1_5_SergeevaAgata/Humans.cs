﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr14_1_5_SergeevaAgata
{
    class Humans
    {
        public string lastname { get; set; }
        public string name { get; set; }
        public string otfather { get; set; }
        public int age { get; set; }
        public double weidth { get; set; }

    }
}
